def dummy_function():
    print("Hello from dummy_function!")