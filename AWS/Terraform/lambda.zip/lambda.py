import json
import dummy_module
import os
import io
import boto3
import json
import csv

ENDPOINT_NAME = "summarizer-endpoint"
runtime= boto3.client('runtime.sagemaker', region_name='us-east-1') # We deploy a single model to us-east-1

def lambda_handler(event, context):
    data = json.loads(json.dumps(event['body']))
    payload = data['input']
    
    encoded_text = payload.encode("utf-8")

    # Invoke the SageMaker endpoint
    response = runtime.invoke_endpoint(EndpointName=ENDPOINT_NAME,
                                       ContentType='application/x-text',
                                       Body=encoded_text)

    # Unpack response
    responseBody = response['Body'].read()
    result = json.loads(responseBody)

    # Return the summary
    summary = result['summary_text']
    return summary
